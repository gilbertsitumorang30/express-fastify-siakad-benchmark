#!/bin/bash

vusList=(10 50 100 200)

for vus in "${vusList[@]}"
do
    echo ""
    echo "======================================="
    echo "FASTIFY GRADES TEST - $vus VUs"
    echo "======================================="

    k6 run \
        -e VUS=$vus \
        -e DURATION=30s \
        ./grades_test.js \
        --summary-export=./results/grades_${vus}_summary.json

    echo ""
    echo "======================================="
    echo "FASTIFY REGISTRATION TEST - $vus VUs"
    echo "======================================="

    k6 run \
        -e VUS=$vus \
        -e DURATION=30s \
        ./registration_test.js \
        --summary-export=./results/registration_${vus}_summary.json

done